/* global define */
(function() {
    'use strict';
    define([], function() {
        var BellController = function() {
        };
        return ['$scope', BellController];
    });
})();
