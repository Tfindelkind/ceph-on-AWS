/* global define */
(function() {
    'use strict';
    define([], function() {
        return {
            scope: {
                submitButtonText: '=',
                cancelButtonText: '='
            },
            restrict: 'A',
            link: function(/*scope, elem, attrs*/) {

            }
        };
    });
})();
