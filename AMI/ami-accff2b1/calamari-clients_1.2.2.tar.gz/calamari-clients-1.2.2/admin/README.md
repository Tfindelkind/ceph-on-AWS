#Admin

This project is current not in use. It was initially used for connecting Calamari to a live cluster, but with the 1.2 release the architecture of how cluster hosts are managed has so radically changed that this module was turned off until the next release.

##The plan

 * Upgrade to Angular 1.2, Bootstrap 3
 * Add Angular-Strap
 * Use RequireJS the way we do in [Manage](../manage)
 * Add Multi-Cluster Support
 * Implement User and possibly Role Management for Calamari