/* jshint -W015 */
angular.module('adminApp').run(function() { 'use strict';
window.inktank = { commit: 'v1.2.2-32-931ee58'}; });