Screenshots
-----------

###Dashboard
![Dashboard](Main_Dashboard.png)
###WorkBench
![WorkBench](workbench_with_pg_state_filtering.png)
###Graphs
![Graphs](Graph_UI.png)
###Manage Hosts
![Manage Hosts](manage_default_view.png)
###Manage OSDs
![Manage OSDs](manage_OSD_hosts_view.png)
###Manage OSDs by Host
![Manage OSDs by Host](manage_OSDS_by_host.png)
###Manage Pools
![Manage Pools](manage_pool_view.png)
