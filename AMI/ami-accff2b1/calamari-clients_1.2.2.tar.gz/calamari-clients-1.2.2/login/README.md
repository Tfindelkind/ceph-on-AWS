#Login

This is a nice simple, self contained module which provides a login screen. It does basic validation of login credentials, refusing to submit them if errors exist and basically redirects when the login has been completed. The backend is expected to redirect to this location when there are no valid session credentials.

It is designed to work with a Django Backend which has been made AngularJS aware. It is a minimalist login screen module.
