/* jshint -W105 */
/* global define */
define([], function() { 'use strict'; return { 'git-commit': 'v1.2.2-32-931ee58' }; });