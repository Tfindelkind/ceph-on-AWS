Calamari-clients is being renamed
=================================

To romana https://en.wikipedia.org/wiki/Squid_(food)#Squid_preparation
available here https://github.com/ceph/romana

What does this mean for you?
----------------------------

Nothing much. 
This code will still be available under the same license as before (MIT) see 
https://github.com/ceph/romana/blob/master/LICENSE.txt
It will still be developed in the same way as in the past. PRs against the other repo
will be kindly moved over here for a time.


Where can I go to ask questions or engage the community?
--------------------------------------------------------

Calamari developer documentation: http://calamari.readthedocs.org

Calamari mailing list: http://lists.ceph.com/listinfo.cgi/ceph-calamari-ceph.com

Calamari issue tracker: http://tracker.ceph.com/projects/calamari

