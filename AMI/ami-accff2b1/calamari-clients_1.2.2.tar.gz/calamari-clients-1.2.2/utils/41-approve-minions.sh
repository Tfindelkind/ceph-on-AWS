cd ~/calamari && . env/bin/activate && salt-key -c dev/etc/salt -A
