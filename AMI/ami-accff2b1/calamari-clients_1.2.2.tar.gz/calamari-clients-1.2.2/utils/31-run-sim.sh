#!/bin/bash
cd ~/calamari && source env/bin/activate && minion-sim --count 3
