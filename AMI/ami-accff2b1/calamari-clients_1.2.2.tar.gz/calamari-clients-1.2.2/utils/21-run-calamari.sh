cd ~/calamari && source env/bin/activate && supervisord -n -c dev/supervisord.conf
